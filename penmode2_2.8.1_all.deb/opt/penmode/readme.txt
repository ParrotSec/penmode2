

DISCLAIMER
	Lo script e i files ad esso collegati (readme.txt), di seguito definiti semplicemente PenMode.sh, sono registrati con Licenza OpenSource. Potete usarli, distribuirli e modificarli purché venga sempre citata la fonte e gli autori. Nessun compenso deve essere versato in alcun caso per l'utilizzo o il semplice download di PenMode.sh


FAQ
- questo script mi fa diventare il migliore tra gli Hackers?
No, PenMode.sh non serve a farti diventare il migliore tra gli Hacker, se vuoi diventarlo devi studiare. Questo script consente di fruire rapidamente di una serie di tools che un hacker dovrebbe comunque conoscere già. Per quanto semplici, ogni singolo tool deve essere regolato e settato per funzionare al meglio. Noi abbiamo già inserito nelle righe di comando quelle opzioni e variabili che per la nostra esperienza forniscono le informazioni necessarie e meglio si adattano ad un gran numero di operazioni; questo rende più facile e rapido l'uso dei tools ma non ti esime dal conoscerli.

- Compatibilità
Al momento PenMode.sh funziona solo per BackBox e sulle altre distro Ubuntu-based che abbiano già installati i tools richiesti. 

- Devo installare qualcosa?
No, devi solo scaricare il codice, modificarne i permessi in modo da renderlo eseguibile e lanciarlo.
Cose è penmode?
Come funziona penmode?

- Quali sono i requisiti minimi hardware?
Gli stessi che ti servono per BackBox. Se ti gira BackBox allora stai bene così.

- Quali sono i requisiti minimi software?
Avere BackBox installata

- Perchè devo usare tor?
Perchè le celle delle prigioni sono già abbastanza piene di gente.

- Cos' è socat?
Socat sta per Socket CAT, è un relay che crea canali di comunicazione bidirezionali

- Come funziona socat?
Mettiamo il caso che tu abbia appena cambiato ISP ed il tuo sito ha un nuovo IP. Ma alcune richieste arrivano ancora sul vecchio IP (magari a causa della cache DNS). Vuoi inoltrare il traffico dal vecchio al nuovo IP? Ti serve SoCat.

- Cos è il target?
No, dico: fai sul serio?

- Cosa sono gli argomenti?


- Come scegliere l' attacco da sferrare?
Esistono due modi. Il primo è definito "ad-minchiam" ossia provi. Il secondo richiede esperienza o studio. Lo script di dice quali sono le vulnerabilità. Sta a te sapere come usarle

- Come posso sapere se sono proxato correttamente?
Mi verrebbe da dire "fai un ping"… ma sarei eccezionalmente cattivo… oh, non lo fare eh! 

- Come posso buttare giù il sito del fidanzato della ragazza che mi piace?
"Il fidanzato della ragazza che mi piace"… ma che fumi? Per fare il figo? Allora questa cosa non fa per te.




